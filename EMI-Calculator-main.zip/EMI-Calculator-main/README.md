# EMI-Calculator
The basic aim of this GUI Project is to calculate Loan through user-input.
![Screenshot (22)](https://user-images.githubusercontent.com/108080130/175341179-aa0ee4d1-bb62-449b-9266-a14e93f5367f.png)
